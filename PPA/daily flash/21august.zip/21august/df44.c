#include<stdio.h>
int main()
{
    int n;
    
    printf("Enter number of rows=\n");
    scanf("%d",&n);
    
    for(int row=1;row<=n;row++)
    {
       int i=1;
       for(int col=1;col<=n;col++)
       {
           printf("%d ",2*i);
           i++;
       }
       printf("\n");
    }
    return 0;
}
/*
Enter number of rows=
4
2 4 6 8 
2 4 6 8 
2 4 6 8 
2 4 6 8 

*/
