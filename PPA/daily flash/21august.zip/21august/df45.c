#include<stdio.h>
void main()
{
    char ch;
    printf("Enter character= ");
    scanf("%c",&ch);
  
    printf("ASCII value of %c=%d\n",ch,ch);
   
   
}
/*
Enter character= A
ASCII value of A=65

*/
