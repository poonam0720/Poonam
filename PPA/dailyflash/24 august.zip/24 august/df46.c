#include<stdio.h>
int main()
{
    int n;
    printf("Enter number=\n");
    scanf("%d",&n);
    
    for(int i=1;i<=n;i++)
    {
       printf("%d ",i);
    }
    return 0;
}

/*
Enter number=
10
1 2 3 4 5 6 7 8 9 10
*/
