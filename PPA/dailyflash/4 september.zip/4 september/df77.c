#include<stdio.h>
int main()
{
     int l,b,Area_of_rectangle;
     
     printf("Enter length and breadth=\n");
     scanf("%d %d",&l,&b);
     
     Area_of_rectangle=l*b;
     
     printf("Area of rectangle=%d\n",Area_of_rectangle);
     
     return 0;
}

/*
Enter length and breadth=
10
20
Area of rectangle=200

*/
