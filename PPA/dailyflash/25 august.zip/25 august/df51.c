#include<stdio.h>
int main()
{
    int n;
    printf("Enter number=\n");
    scanf("%d",&n);
    
    printf("Number=%d\n",n);
    
    return 0;
}
/*
Enter number=
11
Number=11

*/
