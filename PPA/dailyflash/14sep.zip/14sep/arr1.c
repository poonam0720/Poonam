#include<stdio.h>
int main()
{  
   int array[]={1,2,3,4,5};
   int length;
  
   length=sizeof(array)/sizeof(int);
    
   printf("Length of array=%d\n",length);
   
}

/*
Length of array=5

*/
