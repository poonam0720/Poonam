#include<stdio.h>
int main(){

      int num;
      
      printf("Enter size of array=\n");
      scanf("%d",&num);
      
      int array[num];
      
      printf("Enter array elements=\n");
      
      for(int itr==0;itr<num;itr++){
      
          scanf("%d",&array[itr]);
      }
      
      
}
